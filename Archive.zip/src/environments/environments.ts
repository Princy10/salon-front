export const environments = {
    production: false,
    BASE_URL: 'http://localhost:8999',
    CONTEXT_PATH: '/salonBeauto',
}
